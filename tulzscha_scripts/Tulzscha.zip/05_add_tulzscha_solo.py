#!/usr/bin/env python3
"""
Script 5: Add Tulzscha to CthulhuWarsSolo.scala
- Setup menu display line (both online and solo blocks)
- Enable-all list
- Toggle handler (n -= 1 / if n == 0)
- DrawRect board token
- GC Deep sort order
- GC Deep DrawItem cases

Run from the root of your cthulhu-wars repo.
"""

import sys

path = "solo/CthulhuWarsSolo.scala"

with open(path, "r") as f:
    content = f.read()

changes = 0

# ── Helper: insert after first occurrence of a target string ─────────────────
def insert_after(content, target, insertion):
    if target not in content:
        return content, False
    idx = content.index(target)
    end = content.index('\n', idx)
    return content[:end+1] + insertion + content[end+1:], True

# ── 1. DrawRect board token ───────────────────────────────────────────────────
# Find the Nyogtha DrawRect line and add Tulzscha after it
targets_drawrect = [
    'case Nyogtha =>',
    'case NyogthaIcon =>',
]
drawrect_inserted = False
for t in targets_drawrect:
    if t in content:
        idx = content.index(t)
        end = content.index('\n', idx)
        indent = ''
        line_start = content.rindex('\n', 0, idx) + 1
        for ch in content[line_start:idx]:
            if ch in (' ', '\t'):
                indent += ch
            else:
                break
        insertion = indent + 'case Tulzscha => DrawRect("n-tulzscha", |(tint), x - 35, y - 75, 70, 85)\n'
        content = content[:end+1] + insertion + content[end+1:]
        print(f"OK: Added Tulzscha DrawRect after {t}")
        drawrect_inserted = True
        changes += 1
        break

if not drawrect_inserted:
    print("WARNING: Could not find DrawRect location for Nyogtha. Manual add needed.")

# ── 2. GC Deep sort order ─────────────────────────────────────────────────────
# Find the Nyogtha sort case and add Tulzscha, then increment Filth
# Pattern: case Nyogtha => N  followed eventually by case Filth => N+1
import re

# Find "case Nyogtha =>" in sort context (small number, not a unit action)
sort_match = re.search(r'([ \t]+case Nyogtha\s*=>\s*)(\d+)', content)
if sort_match:
    nyogtha_num = int(sort_match.group(2))
    tulzscha_num = nyogtha_num + 1
    filth_num = tulzscha_num + 1

    # Insert Tulzscha after Nyogtha sort line
    end_of_nyogtha_sort = sort_match.end()
    line_end = content.index('\n', end_of_nyogtha_sort)
    indent = sort_match.group(1).split('case')[0]
    insertion = '\n' + indent + f'case Tulzscha =>{" " * max(1, 10 - len("Tulzscha"))}{tulzscha_num}'
    content = content[:line_end] + insertion + content[line_end:]
    print(f"OK: Added Tulzscha to GC Deep sort order (value {tulzscha_num})")
    changes += 1

    # Now update Filth's sort number
    filth_match = re.search(r'([ \t]+case Filth\s*=>\s*)(\d+)', content)
    if filth_match:
        old_filth_line = filth_match.group(0)
        new_filth_line = filth_match.group(1) + str(filth_num)
        content = content.replace(old_filth_line, new_filth_line, 1)
        print(f"OK: Updated Filth GC Deep sort order to {filth_num}")
        changes += 1
else:
    print("WARNING: Could not find Nyogtha sort order case. Manual add needed.")

# ── 3. GC Deep DrawItem cases ─────────────────────────────────────────────────
# Find Nyogtha DrawItem cases and add Tulzscha cases after
# Pattern varies; find "case (X, Nyogtha)" entries and add "(X, Tulzscha)" after
# Also add "(Tulzscha, X)" before the Filth cases

# Find the block for (*, Nyogtha) cases
nyogtha_drawitem_match = re.search(r'([ \t]+case \([^,]+,\s*Nyogtha\)[^\n]+\n)+', content)
if nyogtha_drawitem_match:
    block_end = nyogtha_drawitem_match.end()
    existing_nyogtha_block = nyogtha_drawitem_match.group(0)
    # Build Tulzscha block by replacing Nyogtha with Tulzscha in the same block
    tulzscha_block = existing_nyogtha_block.replace(', Nyogtha)', ', Tulzscha)')

    # Also need (Tulzscha, Nyogtha) and (Tulzscha, Tulzscha) cases:
    # Extract indent from first line
    first_line = existing_nyogtha_block.split('\n')[0]
    indent_match = re.match(r'^([ \t]+)', first_line)
    ind = indent_match.group(1) if indent_match else '                '

    # Add Tulzscha-as-predecessor cases using same offsets as Nyogtha
    tulzscha_predecessor = ind + 'case (Tulzscha, Nyogtha) => DrawItem(null, f, Nyogtha, Alive, $, 65 + last.x, last.y)\n'
    tulzscha_self = ind + 'case (Tulzscha, Tulzscha) => DrawItem(null, f, Tulzscha, Alive, $, 65 + last.x, last.y)\n'

    content = content[:block_end] + tulzscha_block + tulzscha_predecessor + tulzscha_self + content[block_end:]
    print("OK: Added Tulzscha GC Deep DrawItem cases")
    changes += 1
else:
    print("WARNING: Could not find Nyogtha GC Deep DrawItem block. Manual add needed.")

# ── 4. Setup menu display line ────────────────────────────────────────────────
# Find UseNyogtha display line(s) and add UseTulzscha after each
count_nyogtha_display = content.count('UseNyogtha')
inserted_display = 0
offset = 0
for m in re.finditer(r'[ \t]*\$\("Variants"[^)]*UseNyogtha[^\n]*\n', content):
    # Find end of the line
    line = m.group(0)
    # Build equivalent Tulzscha line by replacing Nyogtha text
    tulzscha_line = line.replace('UseNyogtha', 'UseTulzscha').replace(
        'NyogthaCard.short', 'TulzschaCard.short').replace(
        '"Nyogtha"', '"Tulzscha"')
    insert_pos = m.end() + offset
    content = content[:insert_pos] + tulzscha_line + content[insert_pos:]
    offset += len(tulzscha_line)
    inserted_display += 1

if inserted_display > 0:
    print(f"OK: Added Tulzscha setup display line ({inserted_display} occurrence(s))")
    changes += 1
else:
    print("WARNING: Could not find UseNyogtha setup display line. Trying simpler pattern...")
    # Simpler fallback: any line mentioning UseNyogtha
    nyogtha_display_matches = [(m.start(), m.end()) for m in re.finditer(r'[^\n]*UseNyogtha[^\n]*\n', content)]
    if nyogtha_display_matches:
        # Insert after the last occurrence
        s, e = nyogtha_display_matches[-1]
        line = content[s:e]
        tulzscha_line = line.replace('UseNyogtha', 'UseTulzscha').replace('NyogthaCard', 'TulzschaCard')
        content = content[:e] + tulzscha_line + content[e:]
        print(f"OK: Added Tulzscha setup display line (fallback)")
        changes += 1

# ── 5. Enable-all list ────────────────────────────────────────────────────────
# Find lists containing UseNyogtha in setup.options ++= and add UseTulzscha
count_inserted_enable = 0
for m in re.finditer(r'(setup\.options \+\+= \$\([^)]*UseNyogtha)', content):
    old = m.group(0)
    new = old.replace('UseNyogtha', 'UseNyogtha, UseTulzscha')
    content = content.replace(old, new, 1)
    count_inserted_enable += 1

if count_inserted_enable > 0:
    print(f"OK: Added UseTulzscha to enable-all list ({count_inserted_enable} occurrence(s))")
    changes += 1
else:
    print("WARNING: Could not find enable-all list containing UseNyogtha.")

# ── 6. Toggle handler ─────────────────────────────────────────────────────────
# Find "n -= 1\n...if (n == 0) {\n    setup.toggle(UseNyogtha)" blocks and add Tulzscha after
nyogtha_toggle_pattern = re.compile(
    r'([ \t]*n -= 1\n[ \t]*if \(n == 0\) \{\n[ \t]*setup\.toggle\(UseNyogtha\)\n[ \t]*setupQuestions\(\)\n[ \t]*\})'
)
matches = list(nyogtha_toggle_pattern.finditer(content))
if matches:
    offset = 0
    for m in matches:
        block = m.group(1)
        tulzscha_block = block.replace('UseNyogtha', 'UseTulzscha')
        insert_pos = m.end() + offset
        content = content[:insert_pos] + '\n' + tulzscha_block + content[insert_pos:]
        offset += len(tulzscha_block) + 1
    print(f"OK: Added Tulzscha toggle handler ({len(matches)} occurrence(s))")
    changes += 1
else:
    print("WARNING: Could not find UseNyogtha toggle handler. Manual add needed.")
    print("Add this block after each UseNyogtha toggle block:")
    print("""
                n -= 1
                if (n == 0) {
                    setup.toggle(UseTulzscha)
                    setupQuestions()
                }""")

with open(path, "w") as f:
    f.write(content)

print(f"\nDone: solo/CthulhuWarsSolo.scala updated ({changes} change groups applied).")
