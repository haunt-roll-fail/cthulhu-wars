#!/usr/bin/env python3
"""
Script 6: Add Tulzscha <img> tags to solo/index.html
Run from the root of your cthulhu-wars repo.
"""

import sys
import re

path = "solo/index.html"

with open(path, "r") as f:
    content = f.read()

changes = 0

# ── 1. Board token img (near other n-*.webp images) ──────────────────────────
targets_token = [
    'n-nyogtha',
    'n-daoloth',
    'n-abhoth',
    'n-byatis',
]

inserted_token = False
for t in targets_token:
    if t in content:
        # Find the img tag containing this id
        pattern = re.compile(r'<img[^>]+id="' + re.escape(t) + r'"[^>]*/>', re.DOTALL)
        m = pattern.search(content)
        if m:
            insert_pos = m.end()
            # Find next newline
            nl = content.index('\n', insert_pos)
            indent_start = content.rindex('\n', 0, m.start()) + 1
            indent = ''
            for ch in content[indent_start:m.start()]:
                if ch in (' ', '\t'):
                    indent += ch
                else:
                    break
            new_img = '\n' + indent + '<img class="asset" id="n-tulzscha" src="webp/images/n-tulzscha.webp" />'
            content = content[:nl] + new_img + content[nl:]
            print(f"OK: Added board token img after {t}")
            inserted_token = True
            changes += 1
            break

if not inserted_token:
    print("WARNING: Could not find board token img location. Manual add needed.")
    print('Add: <img class="asset" id="n-tulzscha" src="webp/images/n-tulzscha.webp" />')

# ── 2. Icon img (near other igoo icon svgs) ───────────────────────────────────
# Look for nyogtha-icon or other igoo icons
targets_icon = [
    'nyogtha-icon',
    'daoloth-icon',
    'abhoth-icon',
    'byatis-icon',
]

inserted_icon = False
for t in targets_icon:
    if t in content:
        pattern = re.compile(r'<img[^>]+id="' + re.escape(t) + r'"[^>]*/>', re.DOTALL)
        m = pattern.search(content)
        if m:
            nl = content.index('\n', m.end())
            indent_start = content.rindex('\n', 0, m.start()) + 1
            indent = ''
            for ch in content[indent_start:m.start()]:
                if ch in (' ', '\t'):
                    indent += ch
                else:
                    break
            new_img = '\n' + indent + '<img class="asset" id="tulzscha-icon" src="webp/info/n-tulzscha.svg" />'
            content = content[:nl] + new_img + content[nl:]
            print(f"OK: Added icon img after {t}")
            inserted_icon = True
            changes += 1
            break

if not inserted_icon:
    print("WARNING: Could not find icon img location. Manual add needed.")
    print('Add: <img class="asset" id="tulzscha-icon" src="webp/info/n-tulzscha.svg" />')

# ── 3. Info card img (near other info:* entries) ──────────────────────────────
targets_info = [
    'info:n-nyogtha',
    'info:n-daoloth',
    'info:n-abhoth',
    'info:n-byatis',
    'info:nyogtha',
    'info:daoloth',
]

inserted_info = False
for t in targets_info:
    if t in content:
        pattern = re.compile(r'<img[^>]+id="' + re.escape(t) + r'"[^>]*/>', re.DOTALL)
        m = pattern.search(content)
        if m:
            nl = content.index('\n', m.end())
            indent_start = content.rindex('\n', 0, m.start()) + 1
            indent = ''
            for ch in content[indent_start:m.start()]:
                if ch in (' ', '\t'):
                    indent += ch
                else:
                    break
            new_img = '\n' + indent + '<img class="asset" id="info:n-tulzscha" src="webp/info/n-tulzscha.svg" />'
            content = content[:nl] + new_img + content[nl:]
            print(f"OK: Added info card img after {t}")
            inserted_info = True
            changes += 1
            break

if not inserted_info:
    print("WARNING: Could not find info card img location. Manual add needed.")
    print('Add: <img class="asset" id="info:n-tulzscha" src="webp/info/n-tulzscha.svg" />')

with open(path, "w") as f:
    f.write(content)

print(f"\nDone: solo/index.html updated ({changes} change(s) applied).")
