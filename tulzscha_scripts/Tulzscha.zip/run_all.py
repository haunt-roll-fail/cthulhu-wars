#!/usr/bin/env python3
"""
Master script: Run all Tulzscha IGOO implementation steps in order.
Run from the ROOT of your cthulhu-wars repo:

    python3 ~/tulzscha_scripts/run_all.py

Or run individual scripts for debugging:

    python3 ~/tulzscha_scripts/01_add_tulzscha_igoos.py
    python3 ~/tulzscha_scripts/02_add_tulzscha_expansion.py
    ...
"""

import subprocess
import sys
import os

# Script directory = same dir as this file
script_dir = os.path.dirname(os.path.abspath(__file__))

scripts = [
    ("01_add_tulzscha_igoos.py",       "Add Tulzscha objects to IGOOs.scala"),
    ("02_add_tulzscha_expansion.py",   "Add Tulzscha logic to IGOOsExpansion"),
    ("03_add_tulzscha_game.py",        "Add UseTulzscha to Game.scala"),
    ("04_add_tulzscha_overlay.py",     "Add Tulzscha info card to overlay.scala"),
    ("05_add_tulzscha_solo.py",        "Add Tulzscha to CthulhuWarsSolo.scala"),
    ("06_add_tulzscha_index_html.py",  "Add Tulzscha img tags to index.html"),
    ("07_ceremony_of_annihilation_hook.py", "Find & guide Ceremony of Annihilation ritual hook"),
]

print("=" * 70)
print("Tulzscha IGOO Implementation — Running all scripts")
print("=" * 70)
print()

all_passed = True
for script, description in scripts:
    script_path = os.path.join(script_dir, script)
    print(f"─── {description}")
    print(f"    Running: {script}")
    result = subprocess.run(
        [sys.executable, script_path],
        capture_output=False,
        text=True
    )
    if result.returncode != 0:
        print(f"    !! FAILED with return code {result.returncode}")
        all_passed = False
        print()
        # Continue anyway — partial success is still useful
    else:
        print()

print("=" * 70)
if all_passed:
    print("All scripts completed successfully.")
else:
    print("Some scripts reported errors. Review output above.")
print()
print("Next steps:")
print()
print("1. Script 07 (Ceremony of Annihilation ritual hook) is diagnostic only —")
print("   it will tell you exactly where to add the ritual intercept manually.")
print()
print("2. Verify Tulzscha images exist:")
print("   ls -la solo/webp/images/n-tulzscha.webp")
print("   ls -la solo/webp/info/n-tulzscha.svg")
print()
print("3. Check image dimensions match DrawRect (70x85):")
print("   sips -g pixelWidth -g pixelHeight solo/webp/images/n-tulzscha.webp")
print()
print("4. Compile and test:")
print("   cd ~/cthulhu-wars/solo && sbt fastOptJS")
print()
print("5. Kill server and restart:")
print("   cd ~/cthulhu-wars/online")
print("   lsof -ti :999 | xargs kill -9")
print("   rm -f cwo.lck")
print('   sbt "run drop-create-run cwo http://localhost:999/ 999"')
print()
print("6. Test in Incognito mode (bypasses JS cache).")
print()
print("=" * 70)
print("Common post-compile issues:")
print()
print("• 'game.phaseEnd' may not exist — check how other triggers detect")
print("  end-of-gather-power (may be a different field or hook).")
print("• 'f.es' for elder signs — verify the actual field name (may be")
print("  f.elderSigns, f.signs, etc.).")
print("• GC Deep crash — if you see a match error involving Tulzscha,")
print("  the GC Deep DrawItem cases may need a different predecessor set.")
print("• If igooCard() has a different signature in your overlay.scala,")
print("  check how Nyogtha's overlay entry calls it and match the pattern.")
print("=" * 70)
