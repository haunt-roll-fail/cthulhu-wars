#!/usr/bin/env python3
"""
Script 3: Add Tulzscha to Game.scala
- Add UseTulzscha game option
- Register in GameOptions.all
Run from the root of your cthulhu-wars repo.
"""

import sys

path = "solo/Game.scala"

with open(path, "r") as f:
    content = f.read()

# ── 1. Add UseTulzscha game option after UseNyogtha (or last IGOO option) ─────
# Try after UseNyogtha first, then fall back to UseByatis pattern
targets = [
    'case object UseNyogtha extends LoyaltyCardGameOption(NyogthaCard)',
    'case object UseDaoloth extends LoyaltyCardGameOption(DaolothCard)',
    'case object UseAbhoth extends LoyaltyCardGameOption(AbhothCard)',
    'case object UseByatis extends LoyaltyCardGameOption(ByatisCard)',
]

inserted_option = False
for target in targets:
    if target in content:
        # find the end of that line
        idx = content.index(target)
        end = content.index('\n', idx)
        content = content[:end+1] + 'case object UseTulzscha extends LoyaltyCardGameOption(TulzschaCard)\n' + content[end+1:]
        print(f"OK: Added UseTulzscha after: {target[:60]}...")
        inserted_option = True
        break

if not inserted_option:
    print("ERROR: Could not find any IGOO LoyaltyCardGameOption to insert after.")
    print("Please manually add: case object UseTulzscha extends LoyaltyCardGameOption(TulzschaCard)")
    sys.exit(1)

# ── 2. Register UseTulzscha in GameOptions.all ────────────────────────────────
# Find the last IGOO in the GameOptions.all list
igoo_options = ['UseNyogtha,', 'UseDaoloth,', 'UseAbhoth,', 'UseByatis,']

inserted_list = False
for opt in igoo_options:
    if opt in content:
        idx = content.index(opt)
        end = content.index('\n', idx)
        # grab indentation
        line_start = content.rindex('\n', 0, idx) + 1
        indent = ''
        for ch in content[line_start:idx]:
            if ch in (' ', '\t'):
                indent += ch
            else:
                break
        content = content[:end+1] + indent + 'UseTulzscha,\n' + content[end+1:]
        print(f"OK: Registered UseTulzscha in GameOptions.all after {opt}")
        inserted_list = True
        break

if not inserted_list:
    print("ERROR: Could not find IGOO entry in GameOptions.all to insert after.")
    print("Please manually add UseTulzscha to the GameOptions.all list.")
    sys.exit(1)

with open(path, "w") as f:
    f.write(content)

print("\nDone: solo/Game.scala updated successfully.")
