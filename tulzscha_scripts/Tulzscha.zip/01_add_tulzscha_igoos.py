#!/usr/bin/env python3
"""
Script 1: Add Tulzscha objects to IGOOs.scala
Run from the root of your cthulhu-wars repo.
"""

import sys

path = "solo/IGOOs.scala"

with open(path, "r") as f:
    content = f.read()

# ── 1. Add loyalty card, icon, and unit class after NyogthaIcon ──────────────
old_card_block = 'case object NyogthaIcon extends UnitClass(Nyogtha.name + " Icon", Token, 0)'

new_card_block = '''\
case object NyogthaIcon extends UnitClass(Nyogtha.name + " Icon", Token, 0)

case object TulzschaCard extends IGOOLoyaltyCard(TulzschaIcon, Tulzscha, power = 4, combat = 1)
case object TulzschaIcon extends UnitClass(Tulzscha.name + " Icon", Token, 0)'''

if old_card_block not in content:
    print("ERROR: Could not find NyogthaIcon block. Check whitespace.")
    sys.exit(1)
content = content.replace(old_card_block, new_card_block, 1)
print("OK: Added TulzschaCard and TulzschaIcon")

# ── 2. Add Tulzscha UnitClass after Nyogtha UnitClass ────────────────────────
old_unit = 'case object Nyogtha extends UnitClass("Nyogtha", GOO, 6) with IGOO'

new_unit = '''\
case object Nyogtha extends UnitClass("Nyogtha", GOO, 6) with IGOO
case object Tulzscha extends UnitClass("Tulzscha", GOO, 4) with IGOO'''

if old_unit not in content:
    print("ERROR: Could not find Nyogtha UnitClass. Check whitespace.")
    sys.exit(1)
content = content.replace(old_unit, new_unit, 1)
print("OK: Added Tulzscha UnitClass")

# ── 3. Add Tulzscha spellbook objects after NightmareWeb ─────────────────────
old_sb = 'case object NightmareWeb extends NeutralSpellbook("Nightmare Web")'

new_sb = '''\
case object NightmareWeb extends NeutralSpellbook("Nightmare Web")

// Tulzscha
case object CeremonyOfAnnihilation extends NeutralSpellbook("Ceremony of Annihilation")'''

if old_sb not in content:
    print("ERROR: Could not find NightmareWeb spellbook. Check whitespace.")
    sys.exit(1)
content = content.replace(old_sb, new_sb, 1)
print("OK: Added CeremonyOfAnnihilation spellbook")

with open(path, "w") as f:
    f.write(content)

print("\nDone: solo/IGOOs.scala updated successfully.")
