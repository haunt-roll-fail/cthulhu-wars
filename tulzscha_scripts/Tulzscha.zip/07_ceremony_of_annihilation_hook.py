#!/usr/bin/env python3
"""
Script 7: Hook Ceremony of Annihilation into the Ritual of Annihilation logic.

The Ritual of Annihilation is typically handled in a Doom phase action or
a dedicated perform() case. We need to intercept the RoA perform to check
if the acting faction has Tulzscha + CeremonyOfAnnihilation, and if so,
offer the alternate resolution.

This script searches multiple candidate files for the ritual pattern.
Run from the root of your cthulhu-wars repo.
"""

import sys
import re
import os

# ── Find which file contains the Ritual of Annihilation perform logic ─────────
candidates = [
    "solo/IGOOs.scala",
    "solo/CthulhuWarsSolo.scala",
    "solo/Actions.scala",
    "solo/Factions.scala",
    "solo/DoomPhase.scala",
    "solo/Expansions.scala",
    "solo/Base.scala",
]

ritual_keywords = [
    "RitualOfAnnihilation",
    "ritualOfAnnihilation",
    "Ritual of Annihilation",
    "RoA",
    "ritualCost",
    "performRitual",
    "DoRitual",
    "RitualAction",
]

print("Searching for Ritual of Annihilation logic...")
found_files = {}
for c in candidates:
    if not os.path.exists(c):
        continue
    with open(c, "r") as f:
        text = f.read()
    hits = [(kw, text.count(kw)) for kw in ritual_keywords if kw in text]
    if hits:
        found_files[c] = hits
        print(f"  {c}: {hits}")

if not found_files:
    # broader search in solo/ directory
    print("Not found in candidates. Searching all .scala files in solo/...")
    for fname in os.listdir("solo"):
        if not fname.endswith(".scala"):
            continue
        fpath = os.path.join("solo", fname)
        with open(fpath, "r") as f:
            text = f.read()
        hits = [(kw, text.count(kw)) for kw in ritual_keywords if kw in text]
        if hits:
            found_files[fpath] = hits
            print(f"  {fpath}: {hits}")

if not found_files:
    print("\nERROR: Could not find Ritual of Annihilation logic in any Scala file.")
    print("Please manually add the Ceremony of Annihilation hook.")
    print()
    print("Find where PerformRitual / RitualOfAnnihilation is handled in a perform() function.")
    print("Before the standard ritual resolution, add:")
    print("""
        // TULZSCHA - Ceremony of Annihilation
        case RitualAction(self, cost) if self.has(Tulzscha) && self.upgrades.has(CeremonyOfAnnihilation) =>
            Ask(self)
                .option(StandardRitualAction(self, cost), "Perform normally (" + cost + " Power)")
                .option(CeremonyOfAnnihilationAction(self), "Ceremony of Annihilation (earn Power, no Doom/ES bonus)")
""")
    print()
    print("Then handle CeremonyOfAnnihilationAction:")
    print("""
        case CeremonyOfAnnihilationAction(self) =>
            val markerPos = game.ritualMarker   // use your actual field name
            self.power += markerPos
            game.ritualMarker += 1              // advance by 1 step
            self.log("used", CeremonyOfAnnihilation.styled(self), "earning", markerPos, "Power")
            EndAction(self)
""")
    sys.exit(1)

# ── Pick the most likely file (most hits) ─────────────────────────────────────
best_file = max(found_files, key=lambda f: sum(v for _, v in found_files[f]))
print(f"\nBest candidate: {best_file}")

with open(best_file, "r") as f:
    content = f.read()

# ── Search for the perform case that handles the actual ritual payment ─────────
# Common patterns: case RitualAction, case PerformRitual, case DoRitual
ritual_action_match = re.search(
    r'case\s+(Perform)?Ritual(Action|Of)?[^\n]*\n',
    content
)

if ritual_action_match:
    print(f"Found ritual action at char {ritual_action_match.start()}: {ritual_action_match.group(0).strip()}")
    print()
    print("="*70)
    print("MANUAL STEP REQUIRED")
    print("="*70)
    print(f"File: {best_file}")
    print()
    print("The Ceremony of Annihilation needs to intercept the ritual action.")
    print("Add these action classes near your other IGOO action classes (in IGOOs.scala):")
    print("""
case class CeremonyOfAnnihilationAction(self : Faction) extends BaseFactionAction(g => "Ceremony of Annihilation: Earn Power instead of Doom")
""")
    print()
    print(f"Then, in the perform() function in {best_file}, BEFORE the existing ritual case, add:")
    print(f"""
        // TULZSCHA - Ceremony of Annihilation
        // Intercept ritual when the acting faction has Tulzscha + CeremonyOfAnnihilation
        // The exact case class name and fields depend on your ritual action definition.
        // Replace 'YourRitualAction(self, ...)' with the actual pattern found at line:
        //   {ritual_action_match.group(0).strip()}
""")
    print("Context around the ritual action (200 chars):")
    s = ritual_action_match.start()
    print(repr(content[max(0, s-100):s+200]))
else:
    print("Could not precisely identify the ritual action case.")
    print("Context around 'Ritual' mentions:")
    for kw in ritual_keywords:
        for m in re.finditer(re.escape(kw), content):
            s, e = m.start(), m.end()
            print(f"\n  '{kw}' at {s}:")
            print(f"  {repr(content[max(0, s-80):e+120])}")

print()
print("="*70)
print("Ceremony of Annihilation logic to add in IGOOs.scala perform():")
print("="*70)
print("""
        // When Tulzscha faction performs a ritual and has Ceremony of Annihilation:
        //   - Pay nothing (no power cost)
        //   - Earn power equal to current ritual marker position
        //   - Advance marker 1 step
        //   - Gain no extra Doom or Elder Signs from this ritual
        //
        // Add a guard to your existing ritual action handler like:
        //
        //   case YourRitualAction(self, cost, ...) if self.has(Tulzscha) && self.upgrades.has(CeremonyOfAnnihilation) =>
        //       Ask(self)
        //           .option(...perform normally...)
        //           .option(CeremonyOfAnnihilationAltAction(self), "Ceremony of Annihilation")
        //
        //   case CeremonyOfAnnihilationAltAction(self) =>
        //       val pos = game.ritualMarkerPosition   // actual field name
        //       self.power += pos
        //       game.ritualMarkerPosition += 1
        //       self.log("used", CeremonyOfAnnihilation.styled(self), "and earned", pos.power)
        //       EndAction(self)
""")
