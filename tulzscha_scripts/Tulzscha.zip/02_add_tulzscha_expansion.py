#!/usr/bin/env python3
"""
Script 2: Add Tulzscha logic to IGOOsExpansion in IGOOs.scala.
Run from the root of your cthulhu-wars repo.
"""

import sys

path = "solo/IGOOs.scala"

with open(path, "r") as f:
    content = f.read()

# ── 1. Add Tulzscha eliminate handler ────────────────────────────────────────
old_elim = '''\
            case Nyogtha =>
                f.units = f.units.%!(_.uclass == Nyogtha)
                f.upgrades :-= FromBelow
                f.upgrades :-= NightmareWeb
                f.loyaltyCards :-= NyogthaCard
                game.loyaltyCards :+= NyogthaCard

            case _ =>'''

new_elim = '''\
            case Nyogtha =>
                f.units = f.units.%!(_.uclass == Nyogtha)
                f.upgrades :-= FromBelow
                f.upgrades :-= NightmareWeb
                f.loyaltyCards :-= NyogthaCard
                game.loyaltyCards :+= NyogthaCard

            case Tulzscha =>
                f.units :-= u
                f.upgrades :-= CeremonyOfAnnihilation

                f.loyaltyCards :-= TulzschaCard
                game.loyaltyCards :+= TulzschaCard

            case _ =>'''

if old_elim not in content:
    print("ERROR: Could not find Nyogtha eliminate block. Inspect repr of lines.")
    sys.exit(1)
content = content.replace(old_elim, new_elim, 1)
print("OK: Added Tulzscha eliminate handler")

# ── 2. Add Tulzscha trigger (Undying Flame) in the triggers() function ────────
old_triggers = '''\
    override def triggers()(implicit game : Game) {
        checkAbhothSpellbook()
        checkInterdimensional()
    }'''

new_triggers = '''\
    def checkTulzschaUndyingFlame()(implicit game : Game) {
        factions.foreach { f =>
            if (f.has(Tulzscha)) {
                if (game.phase == GatherPower && game.phaseEnd) {
                    val otherFactions = factions.but(f)

                    if (otherFactions.exists(_.doom > f.doom)) {
                        f.doom += 1
                        f.log(Tulzscha.styled(f), "gained 1 Doom from", "Undying Flame".styled(f))
                    }

                    if (otherFactions.exists(_.es > f.es)) {
                        f.takeES(1)
                        f.log(Tulzscha.styled(f), "gained 1 Elder Sign from", "Undying Flame".styled(f))
                    }

                    if (otherFactions.exists(_.power > f.power)) {
                        f.power += 1
                        f.log(Tulzscha.styled(f), "gained 1 Power from", "Undying Flame".styled(f))
                    }
                }
            }
        }
    }

    override def triggers()(implicit game : Game) {
        checkAbhothSpellbook()
        checkInterdimensional()
        checkTulzschaUndyingFlame()
    }'''

if old_triggers not in content:
    print("ERROR: Could not find triggers() block. Inspect repr.")
    sys.exit(1)
content = content.replace(old_triggers, new_triggers, 1)
print("OK: Added checkTulzschaUndyingFlame trigger")

# ── 3. Add Tulzscha awaken handler in perform() ───────────────────────────────
# Inside the IndependentGOOAction case, after the Daoloth case and before the Nyogtha case
old_igoo_perform = '''\
                case Daoloth =>
                    self.upgrades :+= CosmicUnity

                case Nyogtha =>'''

new_igoo_perform = '''\
                case Daoloth =>
                    self.upgrades :+= CosmicUnity

                case Tulzscha =>
                    self.upgrades :+= CeremonyOfAnnihilation

                case Nyogtha =>'''

if old_igoo_perform not in content:
    print("ERROR: Could not find Daoloth/Nyogtha case in IndependentGOOAction. Inspect repr.")
    sys.exit(1)
content = content.replace(old_igoo_perform, new_igoo_perform, 1)
print("OK: Added Tulzscha awaken case (CeremonyOfAnnihilation grant)")

# ── 4. Add Ceremony of Annihilation SBR action classes ───────────────────────
old_nightmare_action = '''\
case class NightmareWebMainAction(self : Faction, l : $[Region]) extends OptionFactionAction("Awaken " + Nyogtha.styled(self) + " with " + NightmareWeb.styled(self)) with MainQuestion with Soft
case class NightmareWebAction(self : Faction, r : Region) extends BaseFactionAction(g => "Awaken " + Nyogtha.styled(self) + g.forNPowerWithTax(r, self, 2) + " in", implicit g => r + self.iced(r))'''

new_nightmare_action = '''\
case class NightmareWebMainAction(self : Faction, l : $[Region]) extends OptionFactionAction("Awaken " + Nyogtha.styled(self) + " with " + NightmareWeb.styled(self)) with MainQuestion with Soft
case class NightmareWebAction(self : Faction, r : Region) extends BaseFactionAction(g => "Awaken " + Nyogtha.styled(self) + g.forNPowerWithTax(r, self, 2) + " in", implicit g => r + self.iced(r))

case class TulzschaGivePowerMainAction(self : Faction) extends OptionFactionAction("Give 2 Power to each enemy (Tulzscha SBR)".styled(self)) with MainQuestion with Soft
case class TulzschaGivePowerAction(self : Faction) extends BaseFactionAction(g => "Give 2 Power to each enemy for " + Tulzscha.styled(self) + " Spellbook Requirement")'''

if old_nightmare_action not in content:
    print("ERROR: Could not find NightmareWeb action classes. Inspect repr.")
    sys.exit(1)
content = content.replace(old_nightmare_action, new_nightmare_action, 1)
print("OK: Added TulzschaGivePower action classes")

# ── 5. Add perform() handlers for Tulzscha SBR and CeremonyOfAnnihilation ─────
old_perform_end = '''\
        // ...
        case _ => UnknownContinue
    }
}'''

new_perform_end = '''\
        // TULZSCHA
        case TulzschaGivePowerMainAction(self) =>
            Ask(self).option(TulzschaGivePowerAction(self)).cancel

        case TulzschaGivePowerAction(self) =>
            self.enemies.foreach { f =>
                f.power += 2
                log(f, "gained 2 Power from", Tulzscha.styled(self), "Spellbook Requirement")
            }

            if (self.upgrades.has(CeremonyOfAnnihilation).not) {
                self.upgrades :+= CeremonyOfAnnihilation
                self.log("gained", CeremonyOfAnnihilation.styled(self), "for", Tulzscha.styled(self))
            }

            EndAction(self)

        // ...
        case _ => UnknownContinue
    }
}'''

if old_perform_end not in content:
    print("ERROR: Could not find end of perform() block. Inspect repr.")
    sys.exit(1)
content = content.replace(old_perform_end, new_perform_end, 1)
print("OK: Added Tulzscha perform() handlers")

with open(path, "w") as f:
    f.write(content)

print("\nDone: IGOOsExpansion logic added to solo/IGOOs.scala successfully.")
