#!/usr/bin/env python3
"""
Script 4: Add Tulzscha info card popup to solo/overlay.scala
Run from the root of your cthulhu-wars repo.

IGOOs display both their SBR and spellbook in the overlay, with the spellbook
text faded until the SBR is met. We follow the pattern used for Byatis/Abhoth/etc.
"""

import sys

path = "solo/overlay.scala"

with open(path, "r") as f:
    content = f.read()

# ── Find the Nyogtha case in the info function and add Tulzscha after it ──────
# The IGOO info cases look like: case $("Nyogtha") => loyaltyCard(...)
# We search for any pattern matching Nyogtha's info entry

# Try to find the Nyogtha IGOO overlay entry
targets_to_search = [
    '$("Nyogtha")',
    '"Nyogtha"',
]

found_nyogtha = False
for target in targets_to_search:
    if target in content:
        idx = content.index(target)
        # Find end of that case line/block (next 'case' keyword at same indent)
        # For safety, find the end of line
        end = content.index('\n', idx)

        # Check a few lines ahead to see if there's more to this case
        # (some cases span multiple lines)
        snippet = content[idx:idx+500]
        lines = snippet.split('\n')

        # Walk forward to find where the case ends (next case or closing brace)
        case_end_offset = len(lines[0]) + 1  # at minimum, the first line
        for i, line in enumerate(lines[1:], 1):
            stripped = line.strip()
            if stripped.startswith('case ') or stripped.startswith('}'):
                break
            case_end_offset += len(line) + 1

        insert_pos = idx + case_end_offset

        tulzscha_info = '''\
        case $("Tulzscha") => igooCard(
            TulzschaCard.name,
            TulzschaCard.power,
            TulzschaCard.combat,
            "Pay 4 Power and place Tulzscha in an Area containing your controlled Gate and your Great Old One.",
            "Undying Flame",
            "Gather Power Phase",
            "At the end of the Gather Power Phase, gain 1 Doom if any Faction has more Doom than you, gain 1 Elder Sign if any Faction has more Elder Signs than you, gain 1 Power if any Faction has more Power than you.",
            "Spellbook Requirement",
            "As an Action, each enemy Faction gains 2 Power.",
            CeremonyOfAnnihilation.name,
            "Doom Phase",
            "When you perform a Ritual of Annihilation, you may choose to pay nothing, and instead EARN Power equal to the current position of the Ritual of Annihilation marker, then advance the marker 1 step. You earn no extra Doom points or Elder Signs."
        )
'''

        content = content[:insert_pos] + tulzscha_info + content[insert_pos:]
        print(f"OK: Added Tulzscha igooCard case after Nyogtha in overlay.scala")
        found_nyogtha = True
        break

if not found_nyogtha:
    # Fallback: try to find any IGOO info case and append after it
    for marker in ['$("Byatis")', '$("Abhoth")', '$("Daoloth")']:
        if marker in content:
            idx = content.index(marker)
            snippet = content[idx:idx+500]
            lines = snippet.split('\n')
            case_end_offset = len(lines[0]) + 1
            for i, line in enumerate(lines[1:], 1):
                stripped = line.strip()
                if stripped.startswith('case ') or stripped.startswith('}'):
                    break
                case_end_offset += len(line) + 1
            insert_pos = idx + case_end_offset

            tulzscha_info = '''\
        case $("Tulzscha") => igooCard(
            TulzschaCard.name,
            TulzschaCard.power,
            TulzschaCard.combat,
            "Pay 4 Power and place Tulzscha in an Area containing your controlled Gate and your Great Old One.",
            "Undying Flame",
            "Gather Power Phase",
            "At the end of the Gather Power Phase, gain 1 Doom if any Faction has more Doom than you, gain 1 Elder Sign if any Faction has more Elder Signs than you, gain 1 Power if any Faction has more Power than you.",
            "Spellbook Requirement",
            "As an Action, each enemy Faction gains 2 Power.",
            CeremonyOfAnnihilation.name,
            "Doom Phase",
            "When you perform a Ritual of Annihilation, you may choose to pay nothing, and instead EARN Power equal to the current position of the Ritual of Annihilation marker, then advance the marker 1 step. You earn no extra Doom points or Elder Signs."
        )
'''
            content = content[:insert_pos] + tulzscha_info + content[insert_pos:]
            print(f"OK: Added Tulzscha igooCard case after {marker} in overlay.scala (fallback)")
            found_nyogtha = True
            break

if not found_nyogtha:
    print("ERROR: Could not find any IGOO info case in overlay.scala.")
    print("Please manually add the Tulzscha case to the info function.")
    print()
    print("Add this case in the info pattern match:")
    print('''        case $("Tulzscha") => igooCard(
            TulzschaCard.name, TulzschaCard.power, TulzschaCard.combat,
            "Pay 4 Power and place Tulzscha in an Area containing your controlled Gate and your Great Old One.",
            "Undying Flame", "Gather Power Phase",
            "At the end of the Gather Power Phase, gain 1 Doom if any Faction has more Doom than you, gain 1 Elder Sign if any Faction has more Elder Signs than you, gain 1 Power if any Faction has more Power than you.",
            "Spellbook Requirement", "As an Action, each enemy Faction gains 2 Power.",
            CeremonyOfAnnihilation.name, "Doom Phase",
            "When you perform a Ritual of Annihilation, you may choose to pay nothing and instead EARN Power equal to the current position of the Ritual of Annihilation marker, then advance the marker 1 step."
        )''')
    sys.exit(1)

with open(path, "w") as f:
    f.write(content)

print("\nDone: solo/overlay.scala updated successfully.")
